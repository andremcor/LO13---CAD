#ifndef GUI_H_INCLUDED
#define GUI_H_INCLUDED

#ifdef __APPLE__
#ifndef GL_SILENCE_DEPRECATION
#define GL_SILENCE_DEPRECATION
#endif
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#endif
