#include <stdlib.h>
#include "GUI.h"

int main(int argc, char **argv)
{
  return EXIT_SUCCESS;
}
